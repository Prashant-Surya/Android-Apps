package com.prashant.android.flipv2;

/**
 * Created by Prashant on 28-05-2015.
 */
public class userDetails {
    static String mail;
    static String name;
}
